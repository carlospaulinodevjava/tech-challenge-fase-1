package br.com.fiap.restaurante.gestao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
